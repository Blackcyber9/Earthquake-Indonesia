#Latest indonesian Earthquake

This Package will get the latest eartquake from BMKG |Meteorological, Climatological, and Geophysical agency

## HOW IT WORK?
This package will scrape from [BMKG](https://www.bmkg.go.id) to get latest quake happened in Indonesia.

this package will use beautifulsoup4 and request, to then produce output in the form of JSON that is ready to be used in web or mobile applications.